# PocketSmart AI

A complete FastAPI + Jinja2 + SQLite + Gemini recommendation assistant for Home, Party, and Jewelry planning.

The uploaded specification describes both Flask and FastAPI; this implementation uses FastAPI because the later implementation milestones, routes, authentication, frontend, and conclusion consistently specify FastAPI/Uvicorn.

## Run in VS Code

1. Install Python 3.11+.
2. Open this folder in VS Code.
3. Create a virtual environment:
   - Windows: `py -3.11 -m venv .venv`
   - macOS/Linux: `python3.11 -m venv .venv`
4. Activate it.
5. Install: `pip install -r requirements.txt`
6. Copy `.env.example` to `.env`.
7. Add a Gemini API key if you want live Gemini recommendations.
8. Start:
   `uvicorn app.main:app --reload`
9. Open `http://127.0.0.1:8000`.
10. Test with `pytest -q`.

If no Gemini key is configured, the app uses deterministic local fallback recommendations, so the application still runs.

## Important external-platform note

The specification names Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO, but it does not provide official API contracts or credentials. This implementation therefore uses a local demo catalog adapter rather than scraping those sites. Replace `app/services/catalog_service.py` with permitted official APIs/affiliate APIs when available.

## Main API

- POST `/register`
- POST `/login`
- POST `/token`
- GET `/logout`
- GET `/session-info`
- GET `/session-data`
- POST `/generate-home`
- POST `/generate-party`
- POST `/generate-jewelry`
- GET `/recommendations-details/{history_id}`
- GET `/history`
- GET `/startup`
- Swagger: `/docs`
