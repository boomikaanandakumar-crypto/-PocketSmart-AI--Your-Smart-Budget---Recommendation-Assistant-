// Shared frontend JavaScript helpers can be added here.
