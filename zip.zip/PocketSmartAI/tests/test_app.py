def register_and_login(client):
    r = client.post("/register", json={
        "full_name":"Test User","email":"test@example.com","password":"password123"
    })
    assert r.status_code == 200
    r = client.post("/login", json={"email":"test@example.com","password":"password123"})
    assert r.status_code == 200

def test_startup(client):
    r = client.get("/startup")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_auth_and_home(client):
    register_and_login(client)
    r = client.post("/generate-home", json={
        "budget":20000,"rooms":["Living Room"],"style":"modern",
        "items":[{"category":"lighting","quantity":2,"notes":""}]
    })
    assert r.status_code == 200
    assert r.json()["planner"] == "home"
    assert r.json()["total_estimated"] <= 20000

def test_party(client):
    register_and_login(client)
    r = client.post("/generate-party", json={
        "budget":30000,"guests":20,"event_type":"birthday",
        "venue":"flexible","preferences":"simple"
    })
    assert r.status_code == 200
    assert r.json()["planner"] == "party"

def test_protected_route_requires_login(client):
    r = client.get("/session-info")
    assert r.status_code == 401
