from typing import Optional
from pydantic import BaseModel, ConfigDict, Field

class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=5, max_length=255)
    password: str = Field(min_length=8, max_length=128)

class LoginRequest(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class HomeItem(BaseModel):
    category: str
    quantity: int = Field(default=1, ge=1, le=100)
    notes: str = ""

class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    rooms: list[str] = Field(min_length=1, max_length=10)
    style: str = Field(default="modern", max_length=80)
    items: list[HomeItem] = Field(default_factory=list)

class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=10_000_000)
    guests: int = Field(gt=0, le=100_000)
    event_type: str = Field(min_length=2, max_length=80)
    venue: str = Field(default="flexible", max_length=120)
    preferences: str = Field(default="", max_length=1000)

class Recommendation(BaseModel):
    name: str
    category: str
    platform: str
    estimated_price: float
    quantity: int = 1
    reason: str
    url: Optional[str] = None

class RecommendationResponse(BaseModel):
    planner: str
    budget: float
    total_estimated: float
    remaining_budget: float
    summary: str
    recommendations: list[Recommendation]
    budget_allocation: dict[str, float] = {}
    source: str = "fallback"

class HistoryItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    planner: str
    created_at: str
