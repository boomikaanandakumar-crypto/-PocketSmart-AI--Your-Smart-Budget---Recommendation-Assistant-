import json
from io import BytesIO
from pathlib import Path
from typing import Annotated
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from PIL import Image, UnidentifiedImageError
from sqlalchemy.orm import Session
from app.config import get_settings
from app.database import get_db
from app.dependencies import get_current_user
from app.models import User, RecommendationHistory
from app.schemas import HomeRequest, PartyRequest, RecommendationResponse
from app.services.catalog_service import home_candidates, party_candidates, jewelry_candidates
from app.services.gemini_service import gemini_service

router = APIRouter(tags=["recommendations"])
settings = get_settings()
Path("uploads").mkdir(exist_ok=True)

def fallback_result(planner, budget, candidates, payload):
    recommendations, total = [], 0.0
    for c in candidates:
        qty = 1
        if planner == "home":
            for item in payload.get("items", []):
                if item.get("category", "").lower() == c.category.lower():
                    qty = int(item.get("quantity", 1)); break
        elif planner == "party" and c.category == "catering":
            qty = int(payload.get("guests", 1))
        cost = c.price * qty
        if total + cost <= budget:
            recommendations.append({
                "name": c.name, "category": c.category, "platform": c.platform,
                "estimated_price": c.price, "quantity": qty, "reason": c.reason, "url": None
            })
            total += cost
    allocation = {}
    for r in recommendations:
        allocation[r["category"]] = allocation.get(r["category"], 0) + r["estimated_price"] * r["quantity"]
    return {
        "planner": planner, "budget": budget, "total_estimated": round(total, 2),
        "remaining_budget": round(max(0, budget-total), 2),
        "summary": f"Demo recommendations selected within your ₹{budget:,.0f} budget.",
        "recommendations": recommendations, "budget_allocation": allocation,
        "source": "fallback",
    }

def save_history(db, user_id, planner, payload, result):
    row = RecommendationHistory(
        user_id=user_id, planner=planner,
        request_json=json.dumps(payload, ensure_ascii=False),
        response_json=json.dumps(result, ensure_ascii=False),
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def merge_ai(result, ai, budget):
    if not ai: return result
    result.update({
        "summary": ai.get("summary", result["summary"]),
        "recommendations": ai.get("recommendations", result["recommendations"]),
        "budget_allocation": ai.get("budget_allocation", result["budget_allocation"]),
        "source": "gemini",
    })
    result["total_estimated"] = round(sum(
        float(x.get("estimated_price", 0)) * int(x.get("quantity", 1))
        for x in result["recommendations"]
    ), 2)
    result["remaining_budget"] = round(max(0, budget - result["total_estimated"]), 2)
    return result

@router.post("/generate-home", response_model=RecommendationResponse)
def generate_home(data: HomeRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    payload = data.model_dump()
    candidates = home_candidates(data.style, data.rooms, [x.category for x in data.items])
    result = fallback_result("home", data.budget, candidates, payload)
    result = merge_ai(result, gemini_service.generate("home", payload, candidates), data.budget)
    save_history(db, user.id, "home", payload, result)
    return result

@router.post("/generate-party", response_model=RecommendationResponse)
def generate_party(data: PartyRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    payload = data.model_dump()
    candidates = party_candidates(data.event_type)
    result = fallback_result("party", data.budget, candidates, payload)
    result = merge_ai(result, gemini_service.generate("party", payload, candidates), data.budget)
    save_history(db, user.id, "party", payload, result)
    return result

@router.post("/generate-jewelry", response_model=RecommendationResponse)
async def generate_jewelry(
    budget: Annotated[float, Form(gt=0, le=10_000_000)],
    occasion: Annotated[str, Form(min_length=2, max_length=80)],
    style: Annotated[str, Form(min_length=2, max_length=80)],
    outfit_notes: Annotated[str, Form(max_length=1000)] = "",
    image: UploadFile | None = File(default=None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    payload = {"budget": budget, "occasion": occasion, "style": style, "outfit_notes": outfit_notes}
    pil_image = None
    if image and image.filename:
        if image.content_type not in {"image/jpeg", "image/png", "image/webp"}:
            raise HTTPException(status_code=400, detail="Only JPG, PNG, or WebP images are allowed")
        raw = await image.read()
        if len(raw) > settings.max_upload_mb * 1024 * 1024:
            raise HTTPException(status_code=400, detail="Image is too large")
        try:
            pil_image = Image.open(BytesIO(raw)).convert("RGB")
        except (UnidentifiedImageError, OSError):
            raise HTTPException(status_code=400, detail="Invalid image file")
    candidates = jewelry_candidates(occasion, style)
    result = fallback_result("jewelry", budget, candidates, payload)
    result = merge_ai(result, gemini_service.generate("jewelry", payload, candidates, pil_image), budget)
    save_history(db, user.id, "jewelry", payload, result)
    return result

@router.get("/recommendations-details/{history_id}")
def recommendation_details(history_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.query(RecommendationHistory).filter(
        RecommendationHistory.id == history_id, RecommendationHistory.user_id == user.id
    ).first()
    if not row: raise HTTPException(status_code=404, detail="Recommendation not found")
    return json.loads(row.response_json)

@router.get("/history")
def history_api(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(RecommendationHistory).filter(
        RecommendationHistory.user_id == user.id
    ).order_by(RecommendationHistory.created_at.desc()).all()
    return [{"id": r.id, "planner": r.planner, "created_at": r.created_at.isoformat()} for r in rows]

@router.get("/session-info")
def session_info(user: User = Depends(get_current_user)):
    return {"authenticated": True, "user_id": user.id, "email": user.email, "full_name": user.full_name}

@router.get("/session-data")
def session_data(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    count = db.query(RecommendationHistory).filter(RecommendationHistory.user_id == user.id).count()
    return {"user_id": user.id, "recommendation_count": count}

@router.get("/startup")
def startup_status():
    return {"status": "ok", "gemini_enabled": gemini_service.enabled, "model": settings.gemini_model}
