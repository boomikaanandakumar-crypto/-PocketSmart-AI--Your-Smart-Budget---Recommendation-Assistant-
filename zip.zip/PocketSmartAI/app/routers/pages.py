import json
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models import User, RecommendationHistory

templates = Jinja2Templates(directory="templates")
router = APIRouter(tags=["pages"])

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    history = db.query(RecommendationHistory).filter(
        RecommendationHistory.user_id == user.id
    ).order_by(RecommendationHistory.created_at.desc()).limit(6).all()
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "history": history})

@router.get("/home-planner", response_class=HTMLResponse)
def home_planner(request: Request, user: User = Depends(get_current_user)):
    return templates.TemplateResponse("planner.html", {"request": request, "user": user, "planner": "home"})

@router.get("/party-planner", response_class=HTMLResponse)
def party_planner(request: Request, user: User = Depends(get_current_user)):
    return templates.TemplateResponse("planner.html", {"request": request, "user": user, "planner": "party"})

@router.get("/jewelry-planner", response_class=HTMLResponse)
def jewelry_planner(request: Request, user: User = Depends(get_current_user)):
    return templates.TemplateResponse("planner.html", {"request": request, "user": user, "planner": "jewelry"})

@router.get("/history", response_class=HTMLResponse)
def history_page(request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(RecommendationHistory).filter(
        RecommendationHistory.user_id == user.id
    ).order_by(RecommendationHistory.created_at.desc()).all()
    return templates.TemplateResponse("history.html", {"request": request, "user": user, "history": rows})

@router.get("/recommendations/{history_id}", response_class=HTMLResponse)
def recommendation_detail(request: Request, history_id: int,
                          user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.query(RecommendationHistory).filter(
        RecommendationHistory.id == history_id,
        RecommendationHistory.user_id == user.id,
    ).first()
    if not row:
        return RedirectResponse("/history", status_code=303)
    result = json.loads(row.response_json)
    return templates.TemplateResponse("results.html", {
        "request": request, "user": user, "result": result, "history_id": row.id
    })
