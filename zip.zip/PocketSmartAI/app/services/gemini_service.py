import json
from typing import Any
from PIL import Image
from google import genai
from google.genai import types
from app.config import get_settings
from app.services.catalog_service import CatalogItem

settings = get_settings()

class GeminiRecommendationService:
    def __init__(self):
        self.client = genai.Client(api_key=settings.gemini_api_key) if settings.gemini_api_key else None

    @property
    def enabled(self) -> bool:
        return self.client is not None

    def _prompt(self, planner: str, payload: dict[str, Any], candidates: list[CatalogItem]) -> str:
        candidate_text = [
            {"name": c.name, "category": c.category, "platform": c.platform,
             "price": c.price, "tags": c.tags, "reason": c.reason}
            for c in candidates
        ]
        return f"""You are PocketSmart AI, a budget-aware recommendation assistant.
Planner: {planner}
User input:
{json.dumps(payload, ensure_ascii=False, indent=2)}

Candidate catalog:
{json.dumps(candidate_text, ensure_ascii=False, indent=2)}

Return ONLY valid JSON with this shape:
{{
  "summary": "short helpful summary",
  "recommendations": [
    {{
      "name": "exact candidate name",
      "category": "category",
      "platform": "platform",
      "estimated_price": 0,
      "quantity": 1,
      "reason": "why it fits"
    }}
  ],
  "budget_allocation": {{"category": 0}}
}}

Rules:
- Use only candidates from the catalog.
- Never invent prices or platform names.
- Keep the total estimated cost within the supplied budget when possible.
- Respect supplied quantities.
- estimated_price is the per-unit price.
"""

    def generate(self, planner: str, payload: dict[str, Any],
                 candidates: list[CatalogItem], image: Image.Image | None = None):
        if not self.enabled:
            return None
        contents: list[Any] = [self._prompt(planner, payload, candidates)]
        if image is not None:
            contents.append(image)
        try:
            response = self.client.models.generate_content(
                model=settings.gemini_model,
                contents=contents,
                config=types.GenerateContentConfig(
                    temperature=0.3,
                    max_output_tokens=1800,
                    response_mime_type="application/json",
                ),
            )
            return json.loads(response.text or "")
        except Exception:
            return None

gemini_service = GeminiRecommendationService()
