from dataclasses import dataclass

@dataclass(frozen=True)
class CatalogItem:
    name: str
    category: str
    platform: str
    price: float
    tags: tuple[str, ...]
    reason: str

CATALOG = [
    CatalogItem("Minimal LED Ceiling Light", "lighting", "Demo Catalog", 1499, ("modern","minimal","living"), "Affordable ambient lighting."),
    CatalogItem("3-Blade Energy Efficient Fan", "fan", "Demo Catalog", 2499, ("modern","bedroom","living"), "Useful everyday cooling within a modest budget."),
    CatalogItem("Compact 4-Seater Dining Table", "dining", "Demo Catalog", 8999, ("modern","dining","wood"), "Space-conscious dining solution."),
    CatalogItem("Neutral Wall Art Set", "decor", "Demo Catalog", 1299, ("minimal","modern","living"), "Adds visual interest without a large spend."),
    CatalogItem("Storage Ottoman", "furniture", "Demo Catalog", 2999, ("modern","storage","bedroom"), "Combines seating and storage."),
    CatalogItem("Warm Accent Floor Lamp", "lighting", "Demo Catalog", 2199, ("warm","minimal","bedroom"), "Creates a softer evening atmosphere."),
    CatalogItem("Budget Veg Catering Package", "catering", "Demo Catalog", 350, ("birthday","vegetarian","corporate"), "Simple per-person catering estimate."),
    CatalogItem("Party Decoration Starter Kit", "decoration", "Demo Catalog", 2499, ("birthday","wedding","celebration"), "Basic decorations for a small event."),
    CatalogItem("Community Hall Package", "venue", "Demo Catalog", 12000, ("birthday","corporate","wedding"), "Example venue allowance for planning."),
    CatalogItem("DJ / Music Setup", "entertainment", "Demo Catalog", 7000, ("birthday","wedding","corporate"), "Example entertainment allocation."),
    CatalogItem("Classic Stud Earrings", "earrings", "Demo Catalog", 999, ("classic","formal","wedding"), "Versatile option for many outfits."),
    CatalogItem("Minimal Pendant Set", "necklace", "Demo Catalog", 1499, ("minimal","casual","formal"), "Simple styling for everyday or semi-formal wear."),
    CatalogItem("Traditional Jhumka Pair", "earrings", "Demo Catalog", 1799, ("traditional","wedding","festive"), "Works well with traditional outfits."),
    CatalogItem("Statement Necklace", "necklace", "Demo Catalog", 2499, ("party","festive","statement"), "A stronger focal accessory for celebrations."),
]

def home_candidates(style: str, rooms: list[str], item_categories: list[str]) -> list[CatalogItem]:
    wanted = {x.lower() for x in item_categories}
    style = style.lower()
    scored = []
    for item in CATALOG:
        score = 0
        if item.category in wanted: score += 5
        if style in item.tags: score += 3
        if any(room.lower() in item.tags for room in rooms): score += 1
        scored.append((score, item))
    return [item for score, item in sorted(scored, key=lambda x: (-x[0], x[1].price)) if score > 0][:10]

def party_candidates(event_type: str) -> list[CatalogItem]:
    event_type = event_type.lower()
    scored = []
    for item in CATALOG:
        score = 2 if item.category in {"catering","venue","decoration","entertainment"} else 0
        if event_type in item.tags: score += 4
        scored.append((score, item))
    return [item for score, item in sorted(scored, key=lambda x: (-x[0], x[1].price)) if score > 0][:8]

def jewelry_candidates(occasion: str, style: str) -> list[CatalogItem]:
    wanted = {occasion.lower(), style.lower()}
    scored = []
    for item in CATALOG:
        score = 1 + sum(2 for tag in item.tags if tag in wanted)
        scored.append((score, item))
    return [item for score, item in sorted(scored, key=lambda x: (-x[0], x[1].price))][:8]
